package main

import "fmt"

func testfunction() {
	fmt.Printf("here!\n")
}

func main() {
	testfunction()
}
