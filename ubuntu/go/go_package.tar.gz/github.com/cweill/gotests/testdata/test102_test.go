package testdata

import "fmt"

var example102 = fmt.Sprintf("test%v", 1)
