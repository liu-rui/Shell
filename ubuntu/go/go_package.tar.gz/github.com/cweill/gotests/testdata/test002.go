package testdata

func Foo2(string, int) {}
