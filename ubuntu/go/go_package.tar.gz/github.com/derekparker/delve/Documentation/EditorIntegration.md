The following editor plugins for delve are available:

* [Golang Plugin for IntelliJ IDEA](https://github.com/go-lang-plugin-org/go-lang-idea-plugin)
* [Go for Visual Studio Code](https://github.com/Microsoft/vscode-go)
* [Emacs plugin](https://github.com/benma/go-dlv.el/)
* [LiteIDE](https://github.com/visualfc/liteide)
* [Go Debugger for Atom](https://github.com/lloiser/go-debug)
